تو تب network این خطا ها رو اوورده که اینها وجود ندارن

http://localhost/paresang/assets/css/material-dashboard.css
http://localhost/paresang/assets/js/material-dashboard.js

لینک این فایلها رو بده تا دانلودون کنم