header.php
footer.php
init.php
auth.php
sidebar.php
functions.php










